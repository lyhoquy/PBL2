// 2 cau lenh dau voi cau lenh cuoi cua moi Package laf de tranh bi loi definition 

#ifndef PACKAGE_H
#define PACKAGE_H

#include <iostream>
#include <iomanip>
#include <conio.h>

class Package
{
public:
    virtual int GetPrice() = 0;
};

#endif

